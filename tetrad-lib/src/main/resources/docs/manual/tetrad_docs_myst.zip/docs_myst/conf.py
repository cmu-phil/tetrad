project = 'Tetrad Manual'
extensions = ['myst_parser']
templates_path = ['_templates']
exclude_patterns = []
html_static_path = ['_static']
source_suffix = {
    '.rst': 'restructuredtext',
    '.md': 'markdown',
}
